<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContentItem extends Model
{
    use HasFactory;

    public const RESULT_TYPES = ['deliverable', 'publication', 'communication_material', 'event_material', 'other_result'];

    public const MEDIA_TYPES = ['news', 'event', 'newsletter', 'press'];

    public const TYPES = [...self::RESULT_TYPES, ...self::MEDIA_TYPES];

    protected $fillable = [
        'type', 'title', 'slug', 'reference_code', 'excerpt', 'body', 'partner',
        'published_at', 'event_date', 'location', 'target_audience', 'registration_url',
        'agenda_url', 'related_resources', 'status', 'category', 'file_path',
        'external_url', 'image_path', 'is_public', 'sort_order',
        'approval_status', 'approved_by', 'approved_at',
    ];

    protected function casts(): array
    {
        return [
            'published_at' => 'date',
            'event_date' => 'datetime',
            'is_public' => 'boolean',
            'approved_at' => 'datetime',
        ];
    }

    public function scopeVisible(Builder $query): Builder
    {
        return $query->where('is_public', true)
            ->where('status', '!=', 'draft')->where('approval_status', 'approved')
            ->where(fn (Builder $q) => $q->whereNull('published_at')->orWhere('published_at', '<=', now()));
    }

    public function getVisibilityLabelAttribute(): string
    {
        if ($this->status === 'draft') {
            return 'Draft';
        }
        if (! $this->is_public) {
            return 'Hidden';
        }
        if ($this->approval_status === 'pending') {
            return 'Awaiting approval';
        }
        if ($this->approval_status !== 'approved') {
            return 'Not approved';
        }
        if ($this->published_at?->isFuture()) {
            return 'Scheduled';
        }

        return 'Public';
    }

    public function getTypeLabelAttribute(): string
    {
        return match ($this->type) {
            'deliverable' => 'Deliverable', 'publication' => 'Publication',
            'communication_material' => 'Communication material', 'event_material' => 'Event material',
            'other_result' => 'Project output', 'news' => 'News', 'event' => 'Event',
            'newsletter' => 'Newsletter', 'press' => 'Press / Media', default => ucfirst($this->type),
        };
    }
}
